import "primereact/resources/themes/saga-blue/theme.css";
import "primereact/resources/primereact.min.css";
import "primeflex/primeflex.css";
import Friteries from "./components/friteries";

function App() {
  return (
    <div>
      <Friteries/>
    </div>
  );
}

export default App;

import IFriterie from "../../../../core/models/iFriterie";

interface FriterieItemProps {
    friterie: IFriterie;
}

export default function FriterieItem(props: FriterieItemProps) {
    return (
        <div>
            <span>
                {props.friterie.name}
            </span>
            <span>
                {props.friterie.address}
            </span>
        </div>
    );
}
export default interface ICoordinates {
    latitude: number;
    longitude: number;
    accuracy: number;
}